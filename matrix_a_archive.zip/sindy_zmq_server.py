import zmq
import numpy as np
import pysindy as ps
import requests
import json
import sys
import argparse
import warnings

warnings.filterwarnings("ignore")
if sys.stdout.encoding.lower() != 'utf-8':
    sys.stdout.reconfigure(encoding='utf-8')

import csv
import os

def run_sindy_and_ollama(history, ai_url, ai_model, no_llm=False, run_label="default"):
    print(f"Data loaded from ZMQ Stream! Shape: {history.shape}")
    
    try:
        import torch
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        vram_gb = history.nbytes / 1e9
        if device.type == 'cuda':
            print(f"--- HARDWARE ACCELERATION ENABLED ---")
            print(f"Pushing {vram_gb:.2f} GB tensor directly into AMD r9700 VRAM...")
        else:
            print(f"Warning: CUDA/ROCm not detected. Using DRAM ({vram_gb:.2f} GB).")
    except ImportError:
        print("PyTorch not installed. Using standard DRAM numpy arrays.")
        device = "cpu"

    tracker_idx = -1
    
    m0_history = history[:, tracker_idx, 7]
    mass_diffs = np.abs(np.diff(m0_history))
    spike_indices = np.where(mass_diffs > 0.1)[0]
    
    if len(spike_indices) > 0:
        firewall_index = spike_indices[0]
        print(f"*** SINGULARITY DETECTED AT TICK {firewall_index} ***")
        history = history[:firewall_index]
    else:
        print("No topological yielding detected. Analyzing full continuous trajectory.")
        
    print(f"Extracting Force/Acceleration vectors for Tracker Particle {tracker_idx}...")
    
    x = history[:, tracker_idx, 1]
    y = history[:, tracker_idx, 2]
    z = history[:, tracker_idx, 3]
    r = np.sqrt(x**2 + y**2 + z**2 + 1e-12)
    hue = np.unwrap(history[:, tracker_idx, 8])
    gamma = history[:, tracker_idx, 9]
    m0 = history[:, tracker_idx, 7]
    px = history[:, tracker_idx, 4]
    py = history[:, tracker_idx, 5]
    pz = history[:, tracker_idx, 6]
    
    if np.all(gamma == 0.0):
        p_sq = px**2 + py**2 + pz**2
        gamma = np.sqrt(1.0 + p_sq / (m0**2 * 1000.0**2))
        
    inv_r3 = np.clip(1.0 / (r**3 + 1e-12), -1e6, 1e6)
    m0_over_gamma = m0 / (gamma + 1e-12)
    sin_hue = np.sin(hue)
    cos_hue = np.cos(hue)
    
    X_features = np.column_stack((x, y, z, r, hue, gamma, m0, inv_r3, sin_hue, cos_hue, m0_over_gamma))
    feature_names = ['x', 'y', 'z', 'r', 'hue', 'gamma', 'm0', '1/r^3', 'sin(hue)', 'cos(hue)', 'm0/gamma']
    
    vx = px / (gamma * m0)
    vy = py / (gamma * m0)
    vz = pz / (gamma * m0)
    r_dot = (x * vx + y * vy + z * vz) / (r + 1e-6)
    
    dt = 0.001
    fd = ps.FiniteDifference()
    
    internal_vars = np.column_stack((hue, gamma, m0))
    internal_dots = fd._differentiate(internal_vars, t=dt)
    X_ddots = fd._differentiate(np.column_stack((vx, vy, vz, r_dot)), t=dt)
    X_targets = np.column_stack((X_ddots, internal_dots))
    
    N_particles = history.shape[1]
    tracker_actual_idx = tracker_idx % N_particles
    
    if N_particles == 2:
        other_idx = 0 if tracker_actual_idx == 1 else 1
        other_pos = history[:, other_idx, 1:4]
        tracker_pos_2b = history[:, tracker_actual_idx, 1:4]
        other_hue = history[:, other_idx, 8]
        
        sep_vec = tracker_pos_2b - other_pos
        d12 = np.sqrt(sep_vec[:, 0]**2 + sep_vec[:, 1]**2 + sep_vec[:, 2]**2 + 1e-12)
        inv_d12_2 = np.clip(1.0 / (d12**2 + 1e-12), -1e6, 1e6)
        inv_d12_3 = np.clip(1.0 / (d12**3 + 1e-12), -1e6, 1e6)
        d_hue = np.unwrap(history[:, tracker_actual_idx, 8]) - np.unwrap(other_hue)
        cos_dhue = np.cos(d_hue)
        
        X_features = np.column_stack((X_features, d12, inv_d12_2, inv_d12_3, cos_dhue))
        feature_names += ['d12', '1/d12^2', '1/d12^3', 'cos(d_hue)']

    if N_particles > 2:
        tracker_pos = history[:, tracker_actual_idx, 1:4]
        tracker_hue_raw = history[:, tracker_actual_idx, 8]
        tracker_mom = history[:, tracker_actual_idx, 4:7]
        tracker_gamma = history[:, tracker_actual_idx, 9]
        tracker_m0_arr = history[:, tracker_actual_idx, 7]
        tracker_vel = tracker_mom / (tracker_gamma[:, np.newaxis] * tracker_m0_arr[:, np.newaxis] + 1e-12)
        
        SPIN_DOT = 0.25
        net_sync = np.zeros(len(tracker_hue_raw))
        net_fx = np.zeros(len(tracker_hue_raw))
        net_fy = np.zeros(len(tracker_hue_raw))
        net_fz = np.zeros(len(tracker_hue_raw))
        net_tx = np.zeros(len(tracker_hue_raw))
        net_ty = np.zeros(len(tracker_hue_raw))
        net_tz = np.zeros(len(tracker_hue_raw))
        
        # Use PyTorch VRAM if available for the massive O(N^2) tensor calculations
        if 'torch' in sys.modules and device.type == 'cuda':
            print("Accelerating N-body Pauli & Torsion feature construction in VRAM...")
            tracker_pos_t = torch.tensor(tracker_pos, device=device, dtype=torch.float32)
            tracker_hue_t = torch.tensor(tracker_hue_raw, device=device, dtype=torch.float32)
            tracker_vel_t = torch.tensor(tracker_vel, device=device, dtype=torch.float32)
            
            net_sync_t = torch.zeros(len(tracker_hue_raw), device=device)
            net_fx_t = torch.zeros(len(tracker_hue_raw), device=device)
            net_fy_t = torch.zeros(len(tracker_hue_raw), device=device)
            net_fz_t = torch.zeros(len(tracker_hue_raw), device=device)
            net_tx_t = torch.zeros(len(tracker_hue_raw), device=device)
            net_ty_t = torch.zeros(len(tracker_hue_raw), device=device)
            net_tz_t = torch.zeros(len(tracker_hue_raw), device=device)
            
            for j in range(N_particles):
                if j == tracker_actual_idx:
                    continue
                other_pos_t = torch.tensor(history[:, j, 1:4], device=device, dtype=torch.float32)
                other_hue_t = torch.tensor(history[:, j, 8], device=device, dtype=torch.float32)
                
                other_mom = history[:, j, 4:7]
                other_gamma = history[:, j, 9]
                other_m0_arr = history[:, j, 7]
                other_vel = other_mom / (other_gamma[:, np.newaxis] * other_m0_arr[:, np.newaxis] + 1e-12)
                other_vel_t = torch.tensor(other_vel, device=device, dtype=torch.float32)
                
                dx = tracker_pos_t[:, 0] - other_pos_t[:, 0]
                dy = tracker_pos_t[:, 1] - other_pos_t[:, 1]
                dz = tracker_pos_t[:, 2] - other_pos_t[:, 2]
                d_hue = tracker_hue_t - other_hue_t
                dist_sq = dx**2 + dy**2 + dz**2 + 1e-6
                
                net_sync_t += torch.sin(d_hue)
                pauli_coupling = SPIN_DOT * torch.cos(d_hue) / (dist_sq**1.5)
                net_fx_t += pauli_coupling * dx
                net_fy_t += pauli_coupling * dy
                net_fz_t += pauli_coupling * dz
                
                dvx = tracker_vel_t[:, 0] - other_vel_t[:, 0]
                dvy = tracker_vel_t[:, 1] - other_vel_t[:, 1]
                dvz = tracker_vel_t[:, 2] - other_vel_t[:, 2]
                cx = dy * dvz - dz * dvy
                cy = dz * dvx - dx * dvz
                cz = dx * dvy - dy * dvx
                tor_denom = dist_sq**2.0
                net_tx_t += dx * cx / tor_denom
                net_ty_t += dy * cy / tor_denom
                net_tz_t += dz * cz / tor_denom
                
            net_sync = net_sync_t.cpu().numpy()
            net_fx = net_fx_t.cpu().numpy()
            net_fy = net_fy_t.cpu().numpy()
            net_fz = net_fz_t.cpu().numpy()
            net_tx = net_tx_t.cpu().numpy()
            net_ty = net_ty_t.cpu().numpy()
            net_tz = net_tz_t.cpu().numpy()
        else:
            for j in range(N_particles):
                if j == tracker_actual_idx:
                    continue
                other_pos = history[:, j, 1:4]
                other_hue = history[:, j, 8]
                other_mom = history[:, j, 4:7]
                other_gamma = history[:, j, 9]
                other_m0_arr = history[:, j, 7]
                other_vel = other_mom / (other_gamma[:, np.newaxis] * other_m0_arr[:, np.newaxis] + 1e-12)
                
                dx = tracker_pos[:, 0] - other_pos[:, 0]
                dy = tracker_pos[:, 1] - other_pos[:, 1]
                dz = tracker_pos[:, 2] - other_pos[:, 2]
                d_hue = tracker_hue_raw - other_hue
                dist_sq = dx**2 + dy**2 + dz**2 + 1e-6
                
                net_sync += np.sin(d_hue)
                pauli_coupling = SPIN_DOT * np.cos(d_hue) / (dist_sq**1.5)
                net_fx += pauli_coupling * dx
                net_fy += pauli_coupling * dy
                net_fz += pauli_coupling * dz
                
                dvx = tracker_vel[:, 0] - other_vel[:, 0]
                dvy = tracker_vel[:, 1] - other_vel[:, 1]
                dvz = tracker_vel[:, 2] - other_vel[:, 2]
                cx = dy * dvz - dz * dvy
                cy = dz * dvx - dx * dvz
                cz = dx * dvy - dy * dvx
                tor_denom = dist_sq**2.0
                net_tx += dx * cx / tor_denom
                net_ty += dy * cy / tor_denom
                net_tz += dz * cz / tor_denom
            
        torsion_mag = np.sqrt(net_tx**2 + net_ty**2 + net_tz**2)
        X_features = np.column_stack((X_features, net_sync, net_fx, net_fy, net_fz, torsion_mag))
        feature_names += ['K_sync', 'F_pauli_x', 'F_pauli_y', 'F_pauli_z', 'F_torsion']
    
    n_targets = X_targets.shape[0]
    n_features = X_features.shape[0]
    if n_features > n_targets:
        trim = n_features - n_targets
        front = trim // 2
        X_features = X_features[front:front + n_targets]
    
    generalized_library = ps.PolynomialLibrary(degree=1, include_bias=True)
    optimizer = ps.STLSQ(threshold=0.005, alpha=0.001)
    model = ps.SINDy(feature_library=generalized_library, optimizer=optimizer)
    
    valid_mask = np.isfinite(X_features).all(axis=1) & np.isfinite(X_targets).all(axis=1)
    X_features = X_features[valid_mask]
    X_targets = X_targets[valid_mask]
    
    print(f"Fitting SINDy Universal Model ({valid_mask.sum()} valid frames). This might take 30-60 seconds...")
    model.fit(X_features, t=dt, x_dot=X_targets, feature_names=feature_names)
    
    equations = [eq for eq in model.equations()]
    lhs = ["vx'", "vy'", "vz'", "r''", "hue'", "gamma'", "m0'"]
    raw_math = "\n".join([f"{lhs[i]} = {eq}" for i, eq in enumerate(equations)])
    
    print("\n========================================")
    print("Cleaned Math Equations:")
    print(raw_math)
    print("========================================\n")
    
    # Write to CSV
    csv_file = "sindy_results.csv"
    file_exists = os.path.isfile(csv_file)
    try:
        with open(csv_file, mode='a', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            if not file_exists:
                writer.writerow(["run_label", "vx'", "vy'", "vz'", "r''", "hue'", "gamma'", "m0'"])
            writer.writerow([run_label] + equations)
        print(f"[BUFFER] Saved extracted equations to {csv_file}")
    except Exception as e:
        print(f"Failed to write to CSV: {e}")
    
    if no_llm:
        print("\n[BUFFER] --- SENDING TO OLLAMA ---")
        print("AI translation disabled via --no_llm. Returning raw equations to GUI.")
        return
        
    print(f"\n[BUFFER] --- SENDING TO OLLAMA ---")
    print(f"Piping output to Ollama API at {ai_url} ({ai_model})...")
    
    prompt = f"""
Act as a world-class theoretical physicist analyzing mathematical data. 
I have built a simulation of a particle collision system in a Weitzenböck lattice (a Teleparallel equivalent to General Relativity). 

I used the PySINDy algorithm to extract the governing differential equations directly from the raw trajectory.

CRITICAL SYSTEM KNOWLEDGE:
- This is a bare-metal test of a 10-dimensional Weitzenböck lattice simulation.
- All hardcoded phenomenological rules (like forced mass-spikes or forced phase synchronization) have been REMOVED.
- You are analyzing the PURE emergent dynamics from the spatial connection. 

EXACT VARIABLE MAPPINGS:
- `x` or `x0`: Spatial X coordinate.
- `y` or `x1`: Spatial Y coordinate.
- `z` or `x2`: Spatial Z coordinate.
- `r` or `x3`: Radial distance from origin.
- `hue` or `x4`: Internal phase angle / oscillation frequency (\\theta_hue).
- `gamma` or `x5`: Relativistic tension / Time dilation factor (\\gamma).
- `m0` or `x6`: Rest mass / Core energy density (m_0).

HERE ARE THE PYSINDY DIFFERENTIAL EQUATIONS FOR THE SYSTEM:
- The left-hand side of the equations (x', y', z', r', hue', gamma', m0') are NOT velocities. They are ACCELERATIONS (or the second derivatives of the structural state).

{raw_math}

INSTRUCTIONS FOR TRANSLATION:
1. Decode this mathematical output strictly using the TEGR / ER=EPR framework provided.
2. Specifically analyze how the internal variables (`hue`, `gamma`, `m0`) behave. 
3. Do NOT use generic terms or spoon-fed answers. Synthesize a profound, original theoretical physics conclusion.
"""

    payload = {
        "model": ai_model,
        "prompt": prompt,
        "stream": False
    }
    
    api_url = ai_url.rstrip('/') + "/api/generate"
    try:
        response = requests.post(api_url, json=payload)
        if response.status_code == 200:
            result = response.json()
            print("\n========================================")
            print("OLLAMA TRANSLATION:")
            print("========================================\n")
            print(result.get("response", "No response text found."))
        else:
            print(f"Ollama API Error: {response.status_code} - {response.text}")
    except requests.exceptions.ConnectionError:
        print("\nERROR: Could not connect to Ollama.")


def main():
    parser = argparse.ArgumentParser(description="ZeroMQ RAM Buffer & PySINDy Server")
    parser.add_argument("--port", type=int, default=7777, help="ZMQ Port to listen on")
    parser.add_argument("--ai_url", type=str, default="http://100.122.147.67:11434", help="Thejfisher Ollama API URL")
    parser.add_argument("--ai_model", type=str, default="gemma4:e4b", help="Ollama model name")
    parser.add_argument("--no_llm", action="store_true", help="Skip Ollama request and just print equations")
    parser.add_argument("--persistent", action="store_true", help="Do not exit after one run (for stress tests)")
    args = parser.parse_args()

    context = zmq.Context()
    socket = context.socket(zmq.PULL)
    socket.bind(f"tcp://*:{args.port}")
    
    print(f"Buffer Node (HAL): Listening on port {args.port} for massive RAM tensor chunks...")
    
    chunks = []
    total_frames = 0
    
    while True:
        message = socket.recv_pyobj()
        status = message.get("status")
        
        if status == "STREAMING":
            data_chunk = message.get("data")
            chunks.append(data_chunk)
            total_frames += data_chunk.shape[0]
            print(f"Received chunk of shape {data_chunk.shape}. Total frames buffered in RAM: {total_frames}")
            
        elif status == "DONE":
            print("Received DONE signal. Stitching DRAM chunks together...")
            if not chunks:
                print("Error: Received DONE but no chunks were sent.")
                break
                
            full_history = np.concatenate(chunks, axis=0)
            print(f"Full trajectory stitched in RAM. Final Shape: {full_history.shape}")
            
            run_label = message.get("run_label", "default")
            # Unleash SINDy
            run_sindy_and_ollama(full_history, args.ai_url, args.ai_model, args.no_llm, run_label=run_label)
            
            print("\nSINDy extraction complete.")
            if not args.persistent:
                print("Server exiting.")
                break
            else:
                print("Persistent mode active. Waiting for next batch...")
                chunks = []
                total_frames = 0

if __name__ == "__main__":
    main()
